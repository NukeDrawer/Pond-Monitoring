package com.hazra.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;

public class registerFragment extends Fragment {
    Button do_Reg;
    private EditText UN,edittextemail,edittextpassword;
    private FirebaseAuth sAuth;
    public registerFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register, container, false);
        do_Reg = view.findViewById(R.id.register);
        sAuth = FirebaseAuth.getInstance();
        edittextemail =  view.findViewById(R.id.emailAddress);
        edittextpassword =  view.findViewById(R.id.password);
        UN =  view.findViewById(R.id.user);

        do_Reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_homeFragment_to_readingFragment);
            }
        });

        return view;
    }
}