package com.hazra.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

public class ReadingFragment extends Fragment {

    public ReadingFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        setHasOptionsMenu(true); //for show option menu icon
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_reading, container, false);

        CardView READ = view.findViewById(R.id.real_time_monitor);
        CardView disease = view.findViewById(R.id.Disease);
        CardView shrimp_types = view.findViewById(R.id.About_Shrimp);
        CardView HATCH = view.findViewById(R.id.Cultivation);
        CardView TYPES = view.findViewById(R.id.TYPES_SHRIMP);
        CardView CULTIVATION = view.findViewById(R.id.CULTIVATION);

        // invisible the bottomNav
        MainActivity.bottomNavigationView.setVisibility(View.INVISIBLE);

        READ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.temperatureFragment);
            }
        });
        disease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.disease_Of_Shrimp_Fragment);
            }
        });
        shrimp_types.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.shrimp_Types_Fragment);
            }
        });
        HATCH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.hatching_Of_Shrimp_Fragment);
            }
        });
        CULTIVATION.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.CUltivation_of_Fragment);
            }
        });
        TYPES.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.types_shrimp_Fragment);
            }
        });

        return view;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.option_menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.optionId:{
                Toast.makeText(requireContext(), "Ok", Toast.LENGTH_SHORT).show();
            }
            default: return super.onOptionsItemSelected(item);
        }
    }
}