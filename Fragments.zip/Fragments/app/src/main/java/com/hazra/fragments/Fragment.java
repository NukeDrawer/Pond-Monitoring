package com.hazra.fragments;

import android.app.Activity;

public class Fragment extends Activity {
}
