package com.hazra.fragments;

public class DataPoint_Light {
    long time_light;
    float y;

    public DataPoint_Light() {
    }

    public DataPoint_Light(long time_light, float y) {
        this.time_light = time_light;
        this.y = y;
    }

    public long getTime_light() {
        return time_light;
    }

    public float getY() {
        return y;
    }
}
