package com.hazra.fragments;

public class DataPoint_Temperature {
    long time;
    float y;

    public DataPoint_Temperature() {
    }

    public DataPoint_Temperature(long time, float y) {
        this.time = time;
        this.y = y;
    }

    public long getTime() {
        return time;
    }

    public float getY() {
        return y;
    }
}
