package com.hazra.fragments;

public class DataPoint_Turbidity {
    long time_tur;
    float y_Tur;

    public DataPoint_Turbidity() {
    }

    public DataPoint_Turbidity(long time_tur, float y_Tur) {
        this.time_tur = time_tur;
        this.y_Tur = y_Tur;
    }

    public long getTime_tur() {
        return time_tur;
    }

    public float getY_Tur() {
        return y_Tur;
    }
}
