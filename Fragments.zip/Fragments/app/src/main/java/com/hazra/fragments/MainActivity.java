package com.hazra.fragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    public static BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NavHostFragment navHostFragment= (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
        bottomNavigationView = findViewById(R.id.bottomBar);
        bottomNavigationView.setVisibility(View.INVISIBLE);//invisible in main activity though
        //it setted here
        NavController navController = navHostFragment.getNavController();
        NavigationUI.setupWithNavController(bottomNavigationView,navController);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.lightFragment,
                R.id.turbidityFragment,R.id.temperatureFragment, R.id.readingFragment).build();
        NavigationUI.setupActionBarWithNavController(this,navController,appBarConfiguration);

    }
}