package com.hazra.fragments;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class LightFragment extends Fragment {
    TextView setLightBtn;
    LineChart lineChart;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref_Light, myref_Light1;
    LineDataSet lineDataSet = new LineDataSet(null, null);
    ArrayList<ILineDataSet> iLineDataSets = new ArrayList<>();
    LineData lineData;

    public LightFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_light, container, false);


        setLightBtn =  view.findViewById(R.id.setLight);
        lineChart =  view.findViewById(R.id.lightlineChart);
        firebaseDatabase = FirebaseDatabase.getInstance();
        myref_Light = firebaseDatabase.getReference("Temperature");
        myref_Light1 = firebaseDatabase.getReference("Chart Values_LIGHT");
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(true);
        lineChart.getAxisRight().setEnabled(false);// right Y axis disable

        Legend l = lineChart.getLegend();
        l.setEnabled(false);

        LimitLine upper_limit = new LimitLine(500,"Danger");
        upper_limit.enableDashedLine(10f,10f,0f);
        upper_limit.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);

        LimitLine lower_limit = new LimitLine(15,"Too Low");
        upper_limit.enableDashedLine(10f,10f,0f);
        upper_limit.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_BOTTOM);

        YAxis yAxisleft = lineChart.getAxisLeft();
        yAxisleft.removeAllLimitLines();
        //yAxisleft.addLimitLine(upper_limit);
        yAxisleft.addLimitLine(lower_limit);
        //yAxisleft.setAxisMaximum(50f);
        yAxisleft.enableGridDashedLine(10f,10f,0);
        yAxisleft.setDrawLimitLinesBehindData(true);

        xAxis.setValueFormatter(new XAxisValueFormatter());// time to X axis
        setListerner();


        return view;
    }

    private void setListerner() {//renamed from insertdata() func
        setLightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myref_Light.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String id = myref_Light1.push().getKey();
                        long x = new Date().getTime();

                        //String L = (String.valueOf(snapshot.child("lux").getValue()));
                        float L = Float.parseFloat(String.valueOf(snapshot.child("lux").getValue()));
                        //int X = Integer.parseInt(L);
                        setLightBtn.setText("Current Light Intensity is: "+L+" lux");

                        DataPoint_Light dataPoint = new DataPoint_Light(x,L);
                        myref_Light1.child(id).setValue(dataPoint);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        myref_Light1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<Entry> datavals = new ArrayList<Entry>();
                if (snapshot.exists()) {
                    for (DataSnapshot myDataSnapshot : snapshot.getChildren()) {
                        DataPoint_Light dataPoint = myDataSnapshot.getValue(DataPoint_Light.class);
                        datavals.add(new Entry(dataPoint.getTime_light(), dataPoint.getY()));
                    }
                    showchart(datavals);
                } else {
                    lineChart.clear();
                    lineChart.invalidate();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void showchart(ArrayList<Entry> datavals) {
        lineDataSet.setValues(datavals);
        lineDataSet.setLabel("TEMP");
        lineDataSet.setColor(Color.RED);
        lineDataSet.setDrawCircles(false);
        lineDataSet.setLineWidth(.5f);
        //lineDataSet.setDrawValues(false);
        lineDataSet.setHighLightColor(Color.BLACK);
        lineDataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        lineDataSet.setCubicIntensity(0.7f);
        lineDataSet.setDrawFilled(true);
        lineDataSet.setFillColor(Color.RED);
        iLineDataSets.clear();
        iLineDataSets.add(lineDataSet);
        lineData = new LineData(iLineDataSets);
        lineChart.clear();
        lineChart.setData(lineData);
        lineChart.invalidate();
    }
    private class XAxisValueFormatter implements IAxisValueFormatter {
        @Override
        public String getFormattedValue(float value, AxisBase axis) {
            axis.setLabelCount(5,true);
            return new SimpleDateFormat("hh:mm", Locale.getDefault()).format(new Date((long) value));
        }
    }

}